from pathlib import Path
import contextlib,io,json,os,resource,shutil,subprocess,sys,types,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'vendor'))
def module_case(i):
 resource.setrlimit(resource.RLIMIT_CPU,(20,20));cases=json.loads((R/'data/paired_cases.json').read_text())['cases'];c=cases[i];work=R/'results'/('paired_'+str(i));work.mkdir();os.chdir(work)
 import editdistance
 editdistance.self_check()
 m=types.ModuleType('setup_cfg_fmt');m.__file__='source/production.py';sys.modules['setup_cfg_fmt']=m;exec(compile(c['source'],m.__file__,'exec'),m.__dict__)
 for name,text in c.get('fixtures',{}).items():assert Path(name).name==name;(work/name).write_text(text)
 obs={'status':'pass','exception':None}
 try:
  if c['kind']=='script':exec(compile(c['test'],'source/test.py','exec'),{'__name__':'__main__'})
  else:
   class FixturePath:
    def __init__(self,p):self.p=Path(p)
    def join(self,n):return FixturePath(self.p/n)
    def write(self,t):self.p.write_text(t)
    def read(self):return self.p.read_text()
    def __str__(self):return str(self.p)
   g={'main':m.main};exec(compile(c['test'],'source/test.py','exec'),g);g['test_rewrite_identifies_license'](FixturePath(work))
 except BaseException as e:obs={'status':'fail','exception':type(e).__name__}
 obs['after']={p.name:p.read_text() for p in work.iterdir() if p.is_file()}
 print('OBSERVATION '+json.dumps(obs),flush=True)
def suite_case(production,suite):
 resource.setrlimit(resource.RLIMIT_CPU,(20,20));work=R/'results'/(production+'__'+suite);project=work/'repository';(project/'tests').mkdir(parents=True)
 shutil.copyfile(R/'licenses/setup-cfg-fmt.txt',project/'LICENSE');shutil.copyfile(R/'source/production'/(production+'.py'),project/'setup_cfg_fmt.py');shutil.copyfile(R/'source/suites'/(suite+'.py'),project/'tests/setup_cfg_fmt_test.py');(project/'tests/__init__.py').write_text('')
 sys.path.insert(0,str(project));os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1';os.chdir(project)
 import editdistance,pytest
 editdistance.self_check();rc=pytest.main(['--assert=plain','-q','-o','addopts=','-p','no:cacheprovider','--color=no','--code-highlight=no','--basetemp',str(work/'tmp'),'--junitxml',str(work/'results.xml'),'tests'])
 root=ET.parse(work/'results.xml').getroot();ts=root if root.tag=='testsuite' else root.find('testsuite');v={k:int(ts.get(k,'0')) for k in ['tests','failures','errors','skipped']};v['passed']=v['tests']-v['failures']-v['errors']-v['skipped'];v['exit']=int(rc);print('OBSERVATION '+json.dumps(v),flush=True)
def main():
 out=R/'results';out.mkdir(exist_ok=False);cases=json.loads((R/'data/paired_cases.json').read_text())['cases'];observations=[]
 for i,c in enumerate(cases):
  p=subprocess.run([sys.executable,'-B',str(R/'reproduce.py'),'--module',str(i)],capture_output=True,text=True,timeout=120);assert p.returncode==0,p.stderr;obs=json.loads(p.stdout.rsplit('OBSERVATION ',1)[1]);assert obs==c['expected'],(i,obs,c['expected']);observations.append(obs)
 plan=[('base','base',(8,0,0,0)),('gold','gold',(18,0,0,0)),('agent','gold',(0,0,1,2)),('gold','agent',(8,1,0,1)),('agent','agent',(9,0,0,0))];suite=[]
 for production,test,wanted in plan:
  p=subprocess.run([sys.executable,'-B',str(R/'reproduce.py'),'--suite',production,test],capture_output=True,text=True,timeout=150);assert p.returncode==0,p.stderr;obs=json.loads(p.stdout.rsplit('OBSERVATION ',1)[1]);assert tuple(obs[k] for k in ['passed','failures','errors','exit'])==wanted,(production,test,obs);suite.append({'production':production,'suite':test,**obs})
 (out/'paired_results.json').write_text(json.dumps(observations,indent=2)+'\n');(out/'suite_results.json').write_text(json.dumps(suite,indent=2)+'\n');print(json.dumps({'result':'PASS','paired_execution_cells':len(observations),'complete_suite_cells':len(suite),'original_containers_replayed':False}),flush=True)
if __name__=='__main__':
 if '--module' in sys.argv:module_case(int(sys.argv[-1]))
 elif '--suite' in sys.argv:suite_case(*sys.argv[-2:])
 else:main()
